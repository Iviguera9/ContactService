package main;

public class Contact {

	private String contactId;
	private String firstName;
	private String lastName;
	private String number;
	private String address;
	
	public Contact(String contactId,String firstName, String lastName, String number, String address) {
		

		setContactId(contactId);
		setFirstName(firstName);
		setLastName(lastName);
		setNumber(number);
		setAddress(address);

	}
	
	public String getContactId() {
		return contactId;
	}
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	
	public String getNumber() {
		return number;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setContactId(String contactId) {
		
		if (contactId == null || contactId.length() > 10) {
			throw new IllegalArgumentException("ID not set or too long");
		}
		
		else {
			
			this.contactId = contactId;
		}
	}
	public void setFirstName(String newFirstName) {
		
		if (newFirstName == null || newFirstName.length() > 10) {
			throw new IllegalArgumentException("First name not set or too long"); 
		}
		this.firstName = newFirstName;
	}
	
	public void setLastName(String newLastName) {
		
		if (newLastName == null || newLastName.length() > 10) {
			throw new IllegalArgumentException("Phone number not set, too long or too short"); 
		}
		this.lastName = newLastName;
	}
	
	public void setNumber(String newNumber) {
		
		if (newNumber == null || newNumber.length() != 10) {
			throw new IllegalArgumentException("Phone number not set, too long or too short"); 
		}
		this.number = newNumber;
	}
	
	public void setAddress(String newAddress) {
		
		if (newAddress == null || newAddress.length() > 30) {
			throw new IllegalArgumentException("Address not set or too long"); 
		}
		this.address = newAddress;
	}
}
