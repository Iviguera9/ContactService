package main;

import java.rmi.server.UID;
import java.util.ArrayList;

public class ContactService {

	public static String userId;
	public String firstN;
	public String lastN;
	public String userNumber;
	public String userAddress;
	
	public static ArrayList<Contact> contactList = new ArrayList<Contact>(0);
	
	public static String uniqueId() {
		
		 return new UID().toString();
	}
	
	public static void addContact(String newFirstName, String newLastName, String newNumber, String newAddress) {
		
		String newId = uniqueId();
		Contact contact = new Contact(newId,newFirstName, newLastName, newNumber, newAddress);
		contactList.add(contact); 
				
	}
	
	public static void addContact(Contact newContact) {
		String tempId = newContact.getContactId();
		
		for (int i=0; i < contactList.size(); i++) {
			
			if (tempId.equals(contactList.get(i).getContactId())) {
				throw new IllegalArgumentException("ID Already Taken");
			}
		}
		contactList.add(newContact);
	} 
	
	public static void curFirstName(String id, String firstN) {
		for (int i = 0; i < contactList.size(); i++) {
			if(id.compareTo(contactList.get(i).getContactId()) == 0) {
				contactList.get(i).setFirstName(firstN);
			}
		}
	}
	 
	public static void curLastName(String id, String lastN) {
		for (int i = 0; i < contactList.size(); i++) {
			if(id.compareTo(contactList.get(i).getContactId()) == 0) {
				contactList.get(i).setLastName(lastN);
			}
		}
	}
	
	public static void curNumber(String id, String userNumber) {
		for (int i = 0; i < contactList.size(); i++) {
			if(id.compareTo(contactList.get(i).getContactId()) == 0) {
				contactList.get(i).setNumber(userNumber);
			}
		}
	}
	
	public static void curAddress(String id, String userAddress) {
		for (int i = 0; i < contactList.size(); i++) {
			if(id.compareTo(contactList.get(i).getContactId()) == 0) {
				contactList.get(i).setAddress(userAddress);
			}
		}
	}
	
	public static void deleteContact(String id) {
		for (int i = 0; i < contactList.size(); i++) {
			if(id.compareTo(contactList.get(i).getContactId()) == 0) {
				int pos = i;
				
				contactList.remove(pos);
			}
		}
	}
	
	public static int searchContact(String id){
		int index = 0;
		
		for(int i = 0; i < contactList.size(); i++) {
			
			if(id.compareTo(contactList.get(i).getContactId()) == 0){
				index = 1;
			}
			else {
				index = 2;
			}
		}
		
		
		return index;
	}
	
	public static int findIndex(String id){
		int index = 0;
		
		for (int i = 0; i < contactList.size(); i++) {
			if (id.compareTo(contactList.get(i).getContactId()) == 0){
				index = i;
			}
		
		}
		return index;
	}
}
	

