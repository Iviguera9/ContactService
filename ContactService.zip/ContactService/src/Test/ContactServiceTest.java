package Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Contact;
import main.ContactService;


 class ContactServiceTest {
	  
	 @Test
	 void testContactService() {
		 ContactService.addContact("Ian", "Viguera", "7879391234", "007 Jupiter Rd. Dallas, Texas 12345");
		 
		 assertTrue(ContactService.contactList.get(0).getContactId().equals("1000000002"));
		 assertTrue(ContactService.contactList.get(0).getFirstName().equals("Ian"));
		 assertTrue(ContactService.contactList.get(0).getLastName().equals("Viguera"));
		 assertTrue(ContactService.contactList.get(0).getNumber().equals("7879391234"));
		 assertTrue(ContactService.contactList.get(0).getAddress().equals("007 Jupiter Rd. Dallas, Texas 12345"));
	 }
	
	 @Test
	 void testDeleteContact() {
		 ContactService.addContact("Ian", "Viguera", "7879391234", "007 Jupiter Rd. Dallas, Texas 12345");
		
		ContactService.deleteContact("1000000003");
		assertTrue(ContactService.searchContact("0000000003") == 3);
	 }
	 
	 @Test
	 void testCurFirstName() {
		 ContactService.addContact("Tom", "Deletion", "7879391236", "227 Abstract Way. Salt Lake, California 55556");
		 int size = ContactService.contactList.size();
		 
		 System.out.println(ContactService.contactList.get(size - 1).getContactId());
			System.out.println(ContactService.contactList.get(size - 1).getFirstName());
			ContactService.curFirstName("1000000003", "Roger");
			System.out.println(ContactService.contactList.get(size - 1).getFirstName());
			assertTrue(ContactService.contactList.get(size - 1).getFirstName().equals("Roger"));
	 }
	 
	 @Test
	 void testCurLastName() {
		 int size = ContactService.contactList.size();
		 ContactService.curLastName("1000000003","Rabbit");
		 assertTrue(ContactService.contactList.get(size-1).getLastName().equals("Rabbit"));
	 }
	 
	 @Test
	 void testCurNumber() {
		 int index = 0;
		 index = ContactService.findIndex("1000000003");
		 ContactService.curNumber("1000000003", "8005551212");
		 assertTrue(ContactService.contactList.get(index).getNumber().equals("8005551212"));
		 
	 } 
	 
	 @Test
	 void testCurAddress() {
		 int index = 0;
		 index = ContactService.findIndex("1000000003");
		 ContactService.curAddress("1000000003", "227 Abstract Way. Salt Lake, California 55556");
		 assertTrue(ContactService.contactList.get(index).getNumber().equals("227 Abstract Way. Salt Lake, California 55556"));
		 
	 }
	 
	 @Test
	 void duplicateId() {
		 Contact newContact = new Contact("1000000004", "Tim", "Berg", "8142223434", "123 Original Ave. Downtown, New Mexico 75030");
		 ContactService.addContact(newContact);
		 Contact dupliContact = new Contact("1000000004", "Tim", "Berg", "8142223434", "123 Duplicate Ave. Downtown, New Mexico 75030");
		 Assertions.assertThrows(IllegalArgumentException.class,()->{
			 ContactService.addContact(dupliContact);
		 });
	 }
	
}
