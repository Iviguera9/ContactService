package Test;

import static org.junit.jupiter.api.Assertions.*; 
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Contact;


 class ContactTest {

	 String id, firstName, lastName, number, address;
	 
	@Test
	void contactTest() {
		
		Contact newContact = new Contact("1000000001", "Ian", "Viguera", "7879391234", "007 Jupiter Rd. Dallas, Texas 12345");
		
		assertTrue(newContact.getContactId().equals("1000000001"));
		assertTrue(newContact.getFirstName().equals("Ian"));
		assertTrue(newContact.getLastName().equals("Viguera"));
		assertTrue(newContact.getNumber().equals("7879391234"));
		assertTrue(newContact.getAddress().equals("007 Jupiter Rd. Dallas, Texas 12345"));
	}
	
	
	@Test
	void longFirstNameTest() {
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("1000000001","Ian000000000000", "Viguera","7879391234", "007 Jupiter Rd. Dallas, Texas 12345");
		});
	}
	
	@Test
	void longLastNameTest() {
	
	Assertions.assertThrows(IllegalArgumentException.class,()->{
		new Contact("1000000001", "Ian", "Viguera0000", "7879391234", "007 Jupiter Rd. Dallas, Texas 12345");
		});
	}
	
	@Test
	void longIdTest() {
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("10000000010","Ian", "Viguera", "7879391234", "007 Jupiter Rd. Dallas, Texas 12345");
		});
	}
	@Test
	void longNumberTest() {
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("1000000001","Ian", "Viguera","78793912340", "007 Jupiter Rd. Dallas, Texas 12345");
		});
	}
	@Test
	void longAddressTest() {
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact( "1000000001","Ian", "Viguera", "7879391234", "007 Jupiter Rd. Dallas, Texas 123450");
		});
	}

	@Test
	void nullFirstNameTest() {
	
	Assertions.assertThrows(IllegalArgumentException.class,()->{
		new Contact( "1000000001",null, "Viguera", "7879391234", "007 Jupiter Rd. Dallas, Texas 12345");
		});
	}
	
	@Test
	void nullLastNameTest() {
	
	Assertions.assertThrows(IllegalArgumentException.class,()->{
		new Contact( "1000000001","Ian", null, "7879391234", "007 Jupiter Rd. Dallas, Texas 12345");
		});
	}
	
	@Test
	void nullIdTest() {
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact(null,"Ian", "Viguera", "7879391234", "007 Jupiter Rd. Dallas, Texas 12345");
		});
	}
	
	@Test
	void nullNumberTest() {
	
	Assertions.assertThrows(IllegalArgumentException.class,()->{
		new Contact("1000000001","Ian", "Viguera", null, "007 Jupiter Rd. Dallas, Texas 12345");
		});
	}
	
	@Test
	void nullAddressTest() {
		
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			new Contact("1000000001","Ian", "Viguera", "7879391234", null);
		});
	}
	
	@Test
	void setFirstName() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez",  "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setFirstName("Benito");
			assertTrue(newContact.getFirstName().equals("Benito"));
			});
		}
	
	@Test
	void setLastName() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez",  "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setLastName("Martinez");
			assertTrue(newContact.getLastName().equals("Martinez"));
			});
	}
	
	@Test
	void setNumber() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez", "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setNumber("7879391235");
			assertTrue(newContact.getNumber().equals("7879391235"));
			});
		}
	
	@Test
	void setAddress() { 
		Contact newContact = new Contact("1000000002","Benito", "Martinez", "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setAddress("123 Red Barrel St. Houston, Texas 00123");
			assertTrue(newContact.getAddress().equals("123 Red Barrel St. Houston, Texas 00123"));
			});
	}
	
	@Test
	void setLongFirstName() {
		Contact newContact = new Contact("1000000002","Benito0000000000", "Martinez", "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setFirstName("First name too long");
			});
	}
	
	@Test
	void setLongLastName() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez", "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setLastName("Last name too long");
			});
	}
	
	@Test
	void setLongNumber() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez", "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setNumber("Phone number too long");
			});
	}
	
	@Test
	void setLongAddress() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez", "7879391235", "123 Red Barrel St. Houston, Texas 00000000000123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setAddress("Address too long");
			});
	}
	
	@Test
	void setShortNumber() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez", "787", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setNumber("Number too short");
			});
	}
	
	@Test
	void setNullFirstName() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez", "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setFirstName(null);
			});
	}
	
	@Test
	void setNullLastName() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez", "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setLastName(null);
			});
	}
	
	@Test
	void setNullNumber() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez", "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setNumber(null);
			});
	}
	@Test
	void setNullAddress() {
		Contact newContact = new Contact("1000000002","Benito", "Martinez", "7879391235", "123 Red Barrel St. Houston, Texas 00123");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			newContact.setAddress(null);
			});
	}



}
