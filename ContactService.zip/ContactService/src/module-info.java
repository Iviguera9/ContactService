/**
 * 
 */
/**
 * @author ianvi
 *
 */
module ContactService {
	requires org.junit.jupiter.api;
	requires java.rmi;
}